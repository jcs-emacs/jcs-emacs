An extensible Emacs dashboard, with sections for
bookmarks, projectil projects, org-agenda and more.
