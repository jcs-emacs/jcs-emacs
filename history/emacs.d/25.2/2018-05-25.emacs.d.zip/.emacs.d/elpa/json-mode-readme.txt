extend the builtin js-mode's syntax highlighting
