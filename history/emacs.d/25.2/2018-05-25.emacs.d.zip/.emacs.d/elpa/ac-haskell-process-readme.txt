Provides an auto-complete source for Haskell which obtains its
completions from the current inferior haskell process (see the
`haskell-process' library included in `haskell-mode').

Installation:

Available as a package in MELPA at http://melpa.org/
M-x package-install ac-haskell-process
