A call to `helm-make' will give you a `helm' selection of this directory
Makefile's targets.  Selecting a target will call `compile' on it.
