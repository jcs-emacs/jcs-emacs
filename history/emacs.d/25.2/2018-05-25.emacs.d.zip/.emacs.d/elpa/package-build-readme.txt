This file allows a curator to publish an archive of Emacs packages.

The archive is generated from a set of recipes which describe elisp
projects and repositories from which to get them.  The term
"package" here is used to mean a specific version of a project that
is prepared for download and installation.
