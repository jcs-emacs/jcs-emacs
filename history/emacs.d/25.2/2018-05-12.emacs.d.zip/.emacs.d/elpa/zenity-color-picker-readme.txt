Insert and adjust colors using Zenity. Zenity
(https://help.gnome.org/users/zenity/stable/) is obviously required.

KNOWN ISSUES

- Color presentation can change between adjustments
- No support for three-letter hex colors
