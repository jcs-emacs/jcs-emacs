Provides a way to easily add `import' statements for Java classes
