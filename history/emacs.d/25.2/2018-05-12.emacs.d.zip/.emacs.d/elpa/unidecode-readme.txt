Transliterate Unicode characters into one of 128 ASCII characters.
This package is an Emacs Lisp port of Python Unidecode package.

Python Unidecode can be found here:
http://pypi.python.org/pypi/Unidecode/

More information in file README.org
