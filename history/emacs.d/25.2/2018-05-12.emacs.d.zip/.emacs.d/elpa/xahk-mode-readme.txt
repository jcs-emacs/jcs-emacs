A major mode for editing AutoHotkey (AHK) script.

for download location and documentation, see:
http://xahlee.info/mswin/emacs_autohotkey_mode.html

Like it?
Buy Xah Emacs Tutorial
http://ergoemacs.org/emacs/buy_xah_emacs_tutorial.html
