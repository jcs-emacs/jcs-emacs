Emacs-eclim uses the Eclim Server to integrate eclipse with Emacs.  This project wants to bring
some of the invaluable features from Eclipse to Emacs.  Please note, the eclim package is limited
to mostly Java support at this time.
