You can install this by (require 'auto-complete-auctex).
Feel free to contribute better documentation!
