This plug-in provides git-p4 functionality as a separate component
of Magit.
