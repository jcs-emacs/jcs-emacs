Provides an interactive command `postcss-sorting-buffer' to sort CSS buffer
using postcss with postcss-sorting plugin.  Supports CSS, SCSS, Less, and
SugarSS syntaxes.

Heavily inspired by the stylefmt.el package:
https://github.com/KeenS/stylefmt.el
