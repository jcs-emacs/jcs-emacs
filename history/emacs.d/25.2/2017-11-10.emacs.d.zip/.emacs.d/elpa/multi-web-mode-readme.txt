Multi Web Mode is a minor mode wich makes web editing in Emacs much easier.

Basically what it does is select the appropriate major mode
automatically when you move the point and also calculates the
correct indentation of chunks according to the indentation of the
most relevant major mode.



