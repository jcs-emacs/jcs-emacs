A major mode for editing abc music files.  Includes some abc2midi
features.


Written for Emacs version 21.  May or may not work with previous
versions.

See the Common Customizations section below.  Or run
`abc-customize'.

This package is stored at https://github.com/mkjunker/abc-mode.
