Look up jps, jstack/java stack trace through helm-interface.
