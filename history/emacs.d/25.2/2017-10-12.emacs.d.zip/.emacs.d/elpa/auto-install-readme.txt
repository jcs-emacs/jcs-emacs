Automates the installation of Emacs Lisp files and packages.

`auto-install' provides an automated way to:

(1) Download Emacs Lisp files and packages from common sources
(2) View them (diff) and save them to your repository
(3) Compile and Load them
