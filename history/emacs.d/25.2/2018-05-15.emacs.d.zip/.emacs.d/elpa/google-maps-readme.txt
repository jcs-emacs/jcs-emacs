Display Google Maps directly inside Emacs.
