aa-edit-mode is Major mode for AA (アスキーアート, known as Shift_JIS art).

https://en.wikipedia.org/wiki/Shift_JIS_art
https://ja.wikipedia.org/wiki/%E3%82%A2%E3%82%B9%E3%82%AD%E3%83%BC%E3%82%A2%E3%83%BC%E3%83%88
