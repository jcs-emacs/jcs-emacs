If you're want to write code according to the [Google C++ Style Guide](http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml), this will help a great deal.

I recommend that the package [google-c-style](http://melpa.milkbox.net/#/google-c-style) also installed with.

For more infomations, please check the GitHub
https://github.com/senda-akiha/flymake-google-cpplint/
