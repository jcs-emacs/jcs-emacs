minimum Emacs version supported is 24.3
