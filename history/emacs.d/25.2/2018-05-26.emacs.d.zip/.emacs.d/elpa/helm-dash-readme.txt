Clone the functionality of dash using helm foundation.  Browse
documentation via dash docsets.

M-x helm-dash
M-x helm-dash-at-point

More info in the project site https://github.com/areina/helm-dash
