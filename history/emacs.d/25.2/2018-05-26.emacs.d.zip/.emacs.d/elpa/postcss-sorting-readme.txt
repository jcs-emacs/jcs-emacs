Provides an interactive command `postcss-sorting-buffer' to sort CSS buffer
using postcss with postcss-sorting plugin.  Support postcss-cli v5 and
postcss-sorting v3.

Heavily inspired by the stylefmt.el package:
https://github.com/KeenS/stylefmt.el
