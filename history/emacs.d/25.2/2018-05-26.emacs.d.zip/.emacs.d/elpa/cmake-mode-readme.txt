Provides syntax highlighting and indentation for CMakeLists.txt and
*.cmake source files.

Add this code to your .emacs file to use the mode:

 (setq load-path (cons (expand-file-name "/dir/with/cmake-mode") load-path))
 (require 'cmake-mode)

------------------------------------------------------------------------------
