The Borg assimilate Emacs packages as Git submodules.  Borg is
an alternative, bare-bones package manager for Emacs packages.

Please consult the manual for more information:
https://www.emacsmirror.net/manual/borg.

Borg can be used by itself or alongside `package.el'.  In the
latter case Borg itself should be installed from Melpa, which
is still experimental and not yet covered in the manual.  See
https://github.com/emacscollective/borg/issues/46 for now.
