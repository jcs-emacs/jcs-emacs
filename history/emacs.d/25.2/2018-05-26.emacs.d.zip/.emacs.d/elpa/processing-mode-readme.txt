Major mode for Processing 2.0.
