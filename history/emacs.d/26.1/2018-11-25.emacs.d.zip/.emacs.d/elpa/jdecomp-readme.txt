Interface to Java decompilers.
