Utilities for better Evil support for Powerline and a few extra themes.
