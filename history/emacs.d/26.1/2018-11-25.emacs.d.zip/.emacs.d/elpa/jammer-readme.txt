This global minor mode allows you to slow down command execution
globally in Emacs.

See the README for more info:
https://github.com/wasamasa/jammer
