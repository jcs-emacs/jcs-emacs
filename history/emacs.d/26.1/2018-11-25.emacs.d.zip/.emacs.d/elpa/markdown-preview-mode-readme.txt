This package makes use of websockets to deliver rendered markdown to a web browser.
Updates happen upon buffer save or on idle.
