This package provides support for working with jar file manifests
(normally named 'manifest.mf' or 'MANIFEST.MF').  It provides basic
syntax checking and keyword highlighting.

TODO
- Deal with x-Digest-y and x-Extension-* style attributes
- Highlight non-conforming entries as an error
