Mimic Eclipse's Organize Imports functionality.

(@* "TODO" )
* Performance is terrible when loading all the jar files to path.
  Hopefully I can find out a way to get around this issue.
