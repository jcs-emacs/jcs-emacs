Nova is an Emacs color theme using Trevor Miller's Nova color scheme
<https://trevordmiller.com/projects/nova>.
