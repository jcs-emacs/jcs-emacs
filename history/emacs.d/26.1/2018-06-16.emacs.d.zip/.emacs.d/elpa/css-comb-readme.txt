Wraps csscomb (https://github.com/csscomb/csscomb.js) for
convenient use in Emacs.  Provides an interactive command `css-comb'.
Beautifies combed css if web-beautify package is installed (recommended)
