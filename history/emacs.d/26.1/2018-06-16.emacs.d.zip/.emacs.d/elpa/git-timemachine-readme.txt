Use git-timemachine to browse historic versions of a file with p
(previous) and n (next).
