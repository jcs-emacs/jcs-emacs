The project is hosted at https://github.com/sabof/auto-auto-indent
The latest version, and all the relevant information can be found there.
