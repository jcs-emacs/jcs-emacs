The homepage for Alpha Tan's original vimrc mode is
<http://vimrc-mode.sf.net>
