`highlight-blocks' provides highlighting of the blocks the point is currently
in.

There are two modes of operation: volatile highlighting
(`highlight-blocks-now') and continuously updated highlighting (the
`highlight-blocks-mode' minor mode).
