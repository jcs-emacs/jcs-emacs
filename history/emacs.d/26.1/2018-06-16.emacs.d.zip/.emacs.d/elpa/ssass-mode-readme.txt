This mode is a clone of sass-mode which works in mmm-mode and doesn't
indent things as eagerly.  Syntax highlighting is provided with
`font-lock-mode'.

Exported names start with "ssass-"; private names start with
"ssass--".
