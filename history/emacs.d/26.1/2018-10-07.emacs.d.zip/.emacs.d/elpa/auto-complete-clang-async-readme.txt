Auto Completion source for clang.
Uses a "completion server" process to utilize libclang.
Also provides flymake syntax checking.
