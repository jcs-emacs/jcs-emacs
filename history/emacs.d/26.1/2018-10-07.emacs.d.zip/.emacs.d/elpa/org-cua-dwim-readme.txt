Commentary:

 To use this, just put in load path and then:

 (require 'org-cua-dwim)
 (org-cua-dwim-activate)
 To activate,
