The project is hosted at https://github.com/sabof/edit-color-stamp
The latest version, and all the relevant information can be found there.

You should find a qt_color_picker folder in the same directory as this file.
If you want to use the QT color picker, go to that folder and run:

$ qmake qt_color_picker.pro; make

then move the qt_color_picker executable somewhere in your path, or point the
ecs-qt-picker-exec variable to it's location.
