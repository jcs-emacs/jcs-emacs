twittering-mode.el is a major mode for Twitter.
You can check friends timeline, and update your status on Emacs.

Feature Request:

URL : http://twitter.com/d00dle/statuses/577876082
* Status Input from Popup buffer and C-cC-c to POST.
URL : http://code.nanigac.com/source/view/419
* update status for region
