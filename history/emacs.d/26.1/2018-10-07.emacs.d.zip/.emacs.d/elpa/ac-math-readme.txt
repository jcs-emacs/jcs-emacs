This add-on defines three ac-sources for the
*[auto-complete](https://github.com/auto-complete)* package:

* ac-source-latex-commands	- input latex commands
* ac-source-math-latex       - input math latex tags  (by default, active only in math environments in latex modes)
* ac-source-math-unicode     - input of unicode symbols (by default, active everywhere except math environments)

Start math completion by typing the prefix "\" key. Select the completion
type RET (`ac-complete`). Completion on TAB (`ac-expand`) is not that great
as you will see dummy characters, but it's usable.

(See https://github.com/vitoshka/ac-math#readme for more)
