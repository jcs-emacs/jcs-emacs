Bind `(ace-jump-zap-up-to-char)' or `(ace-jump-zap-to-char)' to the
key-binding of your choice.
