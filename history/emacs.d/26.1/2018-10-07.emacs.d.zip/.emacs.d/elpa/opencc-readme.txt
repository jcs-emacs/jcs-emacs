`opencc.el' is a package for conversion between Traditional and
Simplified Chinese in Emacs using OpenCC's command line tool.

[OpenCC] https://github.com/BYVoid/OpenCC
