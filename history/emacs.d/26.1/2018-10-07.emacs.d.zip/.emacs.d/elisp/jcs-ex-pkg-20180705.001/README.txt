This is an example package, before publish on melpa.

Please do not include this file in another package. But you can
have another README file.

File include: 
    -> jcs-ex-pkg.el
    -> jcs-ex-pkg.elc
    -> jcs-ex-pkg-pkg.el
    -> REMOVE-THIS-IF-PUBLISH-ON-MELPA.txt
